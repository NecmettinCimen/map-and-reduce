import React, { Fragment } from 'react'
import { Container } from 'semantic-ui-react'
import MenuComponent from './MenuComponent'

class JobScreen extends React.Component {
    render() {
        return (
            <Fragment>
                <MenuComponent />
                <Container text style={{ marginTop: '7em' }}>
                </Container>
            </Fragment>)
    }
}

export default JobScreen