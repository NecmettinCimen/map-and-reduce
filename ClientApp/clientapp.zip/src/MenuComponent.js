import React from 'react'
import { Menu, Container } from 'semantic-ui-react'
import { Link } from 'react-router-dom'

const MenuComponent = () => (
    <Menu fixed='top' inverted>
        <Container>
            <Menu.Item as='a' header>
                Map And Reduce
              </Menu.Item>
            <Link to="/"><Menu.Item >Anasayfa</Menu.Item></Link>
            <Link to="/raporlar"><Menu.Item >Raporlar</Menu.Item></Link>
        </Container>
    </Menu>
)

export default MenuComponent